# Frozen mathematical-modeling support bundle

This bundle contains actual solver outputs, independent evaluation, custom sources,
figures and AI usage disclosures. It does not certify that the mathematical model
is correct for an unstated domain or that this system outperforms other agents.

Read the code first. Use an isolated Python environment with numpy, scipy, pandas,
scikit-learn and numba; exact run versions are in jobs/*/receipt.json and the full
harness report. To reproduce the default baseline confirmation run:

```
python reproduce.py --trust-reviewed-code --candidate baseline --out reproduced
```

For a selected candidate, replace `baseline` with its frozen candidate ID (c0/c1),
and use `--variant full`. Use the exact seeds in protocol.json. Supply
`--original-input DIR` when original contest-provided input was intentionally
excluded; its hashes must match input_manifest.json. The reproducibility script
rejects changed files and out-of-protocol seeds. It never calls an LLM.

The results may be fixture-directed engineering demonstrations; consult
ai_usage.json and AI工具使用详情.pdf. A fixture is not a real Claude review.
